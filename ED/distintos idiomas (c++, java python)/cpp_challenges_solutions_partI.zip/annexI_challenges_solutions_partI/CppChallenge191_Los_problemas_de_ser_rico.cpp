/*
 Acepta el reto - Challenge 191: Los problemas de ser rico
 https://www.aceptaelreto.com/problem/statement.php?id=191
 */

#include <iostream>

using namespace std;

int main()
{
	int numberOfCases;
	int numberOfSections, maxVolume, volumeDifference, total;

	cin >> numberOfCases;
	
	for (int n = 0; n < numberOfCases; n++)
	{
		cin >> numberOfSections >> maxVolume >> volumeDifference;
		total = 0;
		
		for (int i = 0; i < numberOfSections; i++)
			total += maxVolume -  i * volumeDifference;
		
		cout << total << endl;
	}
	return 0;
}
