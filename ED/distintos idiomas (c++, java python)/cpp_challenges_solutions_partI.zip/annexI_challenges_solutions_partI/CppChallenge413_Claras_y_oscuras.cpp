/*
 Acepta el reto - Challenge 413: Claras y oscuras
 https://www.aceptaelreto.com/problem/statement.php?id=413
 */

#include <iostream>

using namespace std;

int main()
{
	int numberOfCases;
	int light, dark, width, height;
	
	cin >> numberOfCases;
	
	for (int i = 0; i < numberOfCases; i++)
	{
		cin >> width >> height;
		light = (width * height) / 2;
		dark = light;
		if ((width * height) % 2 != 0)
			light++;
		cout << light << " " << dark << endl;		
	}

	return 0;
}
