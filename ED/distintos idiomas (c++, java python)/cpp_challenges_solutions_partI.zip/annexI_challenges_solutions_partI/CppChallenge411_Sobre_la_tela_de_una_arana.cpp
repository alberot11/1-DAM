/*
 Acepta el reto - Challenge 411: Sobre la tela de una ara�a
 https://www.aceptaelreto.com/problem/statement.php?id=411
 */

#include <iostream>

using namespace std;

int main()
{
	int maxWeight, totalWeight, currentWeight, numberOfElephants, alreadyBroken;

	do
	{
		cin >> maxWeight;
		
		if (maxWeight > 0)
		{
			totalWeight = 0;
			numberOfElephants = 0;
			alreadyBroken = 0;
			do
			{
				cin >> currentWeight;
				if (currentWeight > 0)
				{
					// We only add a new weight if the spider web is not already broken
					if (totalWeight + currentWeight <= maxWeight && alreadyBroken == 0)
					{
						totalWeight += currentWeight;
						numberOfElephants++;
					} else {
						alreadyBroken = 1;
					}
				}
			} while (currentWeight > 0);
			
			cout << numberOfElephants << endl;
		}
	} while (maxWeight != 0);	
	return 0;
}
