/*
 Acepta el reto - Challenge 208: Tirando bolos
 https://www.aceptaelreto.com/problem/statement.php?id=208
 */

#include <iostream>

using namespace std;

int main()
{
	// We need a huge integer to add all the possible elements
	unsigned long long int numberOfRows, affectedRow, totalBowlingPins, totalDown;
	
	do
	{
		cin >> numberOfRows >> affectedRow;
		
		if (numberOfRows > 0 && affectedRow > 0)
		{
			/* We apply this formula to sum an amount of increasing bowls:
			 * 1 + 2 + 3 + 4 + ... + N = N * (N + 1) / 2
			 */ 			
			totalBowlingPins = numberOfRows * (numberOfRows+1) / 2;
			// We apply the same formula to calculate the amount of knocked down bowls
			totalDown = (numberOfRows - affectedRow + 1) * (numberOfRows - affectedRow + 2) / 2;
			cout << (totalBowlingPins - totalDown) << endl;
		}
	} while (numberOfRows > 0 && affectedRow > 0);
	return 0;
}
