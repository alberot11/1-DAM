/*
 Acepta el reto - Challenge 262: Ada, Babbage y Bernouilli
 https://www.aceptaelreto.com/problem/statement.php?id=262
 */

#include <iostream>

#define MODULE 46337

using namespace std;

int main()
{
	int n, p;

	// To store the final result
	unsigned long long int result;

	// To store partial sums
	unsigned long long int partialResult;
	
	do
	{
		cin >> n >> p;
		
		if (n > 0)
		{
			result = 0;
			
			for(int i = 1; i <= n; i++)
			{
				partialResult = 1;
				
				for (int j = 1; j <= p; j++)
				{
					partialResult = ((partialResult % MODULE) * (i % MODULE)) % MODULE;
				}
				
				result = ((result % MODULE) + (partialResult % MODULE)) % MODULE;
			}
			
			cout << result << endl;
		}
	} while (n > 0);
	return 0;
}
