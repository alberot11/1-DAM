/*
 Acepta el reto - Challenge 369: Contando en la arena
 https://www.aceptaelreto.com/problem/statement.php?id=369
 */

#include <iostream>

using namespace std;

int main()
{
	int number;
	
	do
	{
		// We read the number and print as many "1" as the number says
		cin >> number;
		if (number > 0)
		{
			for (int i = 0; i < number; i++)
				cout << 1;
			cout << endl;
		}
	} while (number > 0);
	return 0;
}
