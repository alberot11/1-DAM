/*
 Acepta el reto - Challenge 116: Hola mundo
 https://www.aceptaelreto.com/problem/statement.php?id=116
 */

#include <iostream>

using namespace std;

int main()
{
	int i, times;
	
	cin >> times;
	for (i = 0; i < times; i++)
		cout << "Hola mundo." << endl;
		
	return 0;
}
