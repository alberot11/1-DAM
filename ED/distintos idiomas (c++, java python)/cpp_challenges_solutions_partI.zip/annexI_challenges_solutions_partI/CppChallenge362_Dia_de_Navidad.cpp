/*
 Acepta el reto - Challenge 362: D�a de Navidad
 https://www.aceptaelreto.com/problem/statement.php?id=362
 */

#include <iostream>

using namespace std;

int main()
{
	int numberOfCases;
	int day, month;
	
	cin >> numberOfCases;
	
	for (int i = 0; i < numberOfCases; i++)
	{
		cin >> day;
		cin >> month;
		if (day == 25 && month == 12)
			cout << "SI" << endl;				// Christmas day
		else
			cout << "NO" << endl;				// NOT Christmas day
	}
	return 0;
}
