/*
 Acepta el reto - Challenge 150: A dibujar hexágonos
 https://www.aceptaelreto.com/problem/statement.php?id=150
 */

#include <iostream>

using namespace std;

int main()
{
	int size, rows, symbolsCurrentRow, spacesCurrentRow;
	char symbol;

	do
	{
		cin >> size >> symbol;
		
		if (size > 0)
		{
			// Determine the number of rows to be drawn
			rows = size * 2 - 1;
			
			// Every row will have a number of left whitespaces...
			symbolsCurrentRow = size;
			// ... and a number of symbols to be drawn
			spacesCurrentRow = size - 1;
			
			for (int i = 1; i <= rows; i++)
			{
				// In the upper part, number of symbols increase 2 units 
				// per row, and whitespaces decrease 1 per row
				if (i > 1 && i <= size)
				{
					symbolsCurrentRow += 2;
					spacesCurrentRow--;
				}
				// In the lower part, symbols decrease and whitespaces
				// increase
				else if (i > size)
				{
					symbolsCurrentRow -= 2;
					spacesCurrentRow++;
				}
				
				// Draw whitespaces and symbols	
				for (int j = 0; j < spacesCurrentRow; j++)
					cout << ' ';
								
				for (int j = 0; j < symbolsCurrentRow; j++)
					cout << symbol;
				

				cout << endl;
			}
		}		
	} while (size > 0);
	return 0;
}
